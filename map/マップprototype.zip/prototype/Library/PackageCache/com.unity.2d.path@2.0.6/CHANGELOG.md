# Changelog
## [2.0.6] - 2020-07-17
### Changed
- Snapping Control Points and Tangents use Global Move Snap settings.

## [2.0.5] - 2020-05-08
### Changed
- Added return for Path tool usage change.

## [2.0.4] - 2019-10-27
### Fixed
- Added missing meta file

## [2.0.3] - 2019-10-02
### Fixed
- Removed resources

## [2.0.2] - 2019-07-24
### Added
- Add related test packages

## [2.0.1] - 2019-07-13
### Changed
- Mark package to support Unity 2019.3.0a10 onwards.

## [2.0.0] - 2019-06-19
### Changed.
- Stable Version.

## [1.0.0-preview.3] - 2019-06-14
### Fixed
- Fix undo on select point.

## [1.0.0-preview.1] - 2019-04-22
### Added
- Initial Version.